<div class="tools">
    <a href="#" class="collapse" data-bs-toggle="tooltip" title="Collapse/Expand" data-bs-original-title="Collapse/Expand"></a>
    <a href="#" class="fullscreen" data-bs-toggle="tooltip" title="Full screen" data-bs-original-title="Full screen"> </a>
</div>
